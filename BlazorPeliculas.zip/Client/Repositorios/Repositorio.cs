﻿using BlazorPeliculas.Shared.Entidades;

namespace BlazorPeliculas.Client.Repositorios
{
    public class Repositorio : IRepositorio
    {
        public List<Pelicula> ObtenerPeliculas()
        {
             return   new List<Pelicula>()
            {
                new Pelicula()  { Titulo = "Los Crods 1000",
                Lanzamiento = new DateTime(2022, 01, 01)    },
                new Pelicula()  { Titulo = "La Bella y la Bestia 1000",
                Lanzamiento = new DateTime(2022, 03, 01)    },
                new Pelicula()  { Titulo = "Thor un mundo oscuro 1000",
                Lanzamiento = new DateTime(2022, 06, 01)    }
            };
        }
    }
}
