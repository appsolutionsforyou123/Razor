﻿function pruebaPuntoNetStatic() {
    Dotnet.invokeMethodAsync("BlazorPeliculas.Client", "ObtenerCurrentCount")
        .then(  resultado => {
                console.log("Conteo desde JavaScript " + resultado);
            });
}