﻿namespace BlazorPeliculas.Client
{
    public class ServicioSingleton
    {
        public int Valor { get; set; }
    }
    public class ServicioTransient
    {
        public int Valor { get; set; }
    }


}
