﻿namespace BlazorPeliculas.Client.Helpers
{
    public class UtilidadesString
    {
        public static string Enmayuscula(string valor) => valor.ToUpper();
    }

}
