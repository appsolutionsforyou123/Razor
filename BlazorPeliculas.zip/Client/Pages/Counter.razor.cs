﻿using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

namespace BlazorPeliculas.Client.Pages
{
    public partial class Counter
    {
        [Inject] ServicioSingleton singletonSrv { get; set; }
        [Inject] ServicioTransient transientSrv { get; set; }

        [Inject] IJSRuntime JS { get; set; }

        protected int currentCount = 0;
        static int currentCountStatic = 0;
        

        private async Task IncrementCount()
        {

            currentCount++;
            singletonSrv.Valor = currentCount;
            transientSrv.Valor = currentCount;
            currentCountStatic++;
            await JS.InvokeVoidAsync("pruebaPuntoNetStatic");
        }

        [JSInvokable]
        public static Task<int> ObtenerCurrentCount()
        {
            return Task.FromResult(currentCountStatic);
        }
    }
}
