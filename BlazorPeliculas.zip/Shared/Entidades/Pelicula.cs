﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorPeliculas.Shared.Entidades
{
    public class Pelicula
    {
        public string Titulo
        {
            get; set;
        }
        public DateTime Lanzamiento
        {
            get; set; 
        }
    }
}
